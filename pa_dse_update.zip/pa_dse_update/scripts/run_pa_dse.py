#!/usr/bin/env python3
"""
run_pa_dse.py

Run PA-DSE on a benchmark and compare it with Grid / Random / LHS.

Usage examples:
  python3 scripts/run_pa_dse.py --benchmark matmul --budget 20 --results-root results/pa_dse
  python3 scripts/run_pa_dse.py --benchmark matmul --budget 20 --results-root results/pa_dse --enable-pipeline
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import pandas as pd

from config_generator import generate_bambu_configs
from compare_strategies import run_strategy
from heuristic import grid_search, random_search, latin_hypercube_search
from pa_dse import PADSE


BENCHMARK_DEFAULTS = {
    "matmul": ("benchmarks/matmul/matmul.c", "matmul"),
    "fir": ("benchmarks/fir/fir.c", "fir"),
    "vadd": ("benchmarks/vadd/vadd.c", "vadd"),
    "histogram": ("benchmarks/histogram/histogram.c", "histogram"),
    "dotprod": ("benchmarks/dotprod/dotprod.c", "dotprod"),
    "stencil": ("benchmarks/stencil/stencil.c", "stencil"),
    "matvec": ("benchmarks/matvec/matvec.c", "matvec"),
    "atax": ("benchmarks/atax/atax.c", "atax"),
    "gemm": ("benchmarks/gemm/gemm.c", "gemm"),
    "spmv": ("benchmarks/spmv/spmv.c", "spmv"),
}


def save_csv(rows, path):
    df = pd.DataFrame(rows)
    df.to_csv(path, index=False)
    print(f"Saved {path}")


def run_all(
    benchmark: str,
    src_file: str,
    top_func: str,
    results_root: str,
    budget: int,
    enable_pipeline: bool,
    ablation_mode: str = "full",
):
    Path(results_root).mkdir(parents=True, exist_ok=True)

    configs = generate_bambu_configs(enable_pipeline=enable_pipeline)

    param_keys = [
        "clock_period",
        "pipeline",
        "memory_policy",
        "channels_type",
        "channels_number",
    ]

    strategies = {
        "Grid Search": grid_search(configs),
        "Random 30%": random_search(configs, sample_ratio=0.3),
        "LHS 20%": latin_hypercube_search(configs, param_keys, sample_ratio=0.2),
    }

    trimmed = {}
    for name, cfgs in strategies.items():
        if name == "Grid Search":
            step = max(1, len(cfgs) // budget)
            trimmed[name] = cfgs[::step][:budget]
        else:
            trimmed[name] = cfgs[:budget]
    strategies = trimmed

    all_stats = []

    print("=" * 60)
    print(f"PA-DSE comparison on benchmark: {benchmark}")
    print(f"Source file: {src_file}")
    print(f"Top function: {top_func}")
    print(f"Pipeline enabled in search space: {enable_pipeline}")
    print(f"Ablation mode: {ablation_mode}")
    print(f"Total design points: {len(configs)}")
    print("=" * 60)

    for strategy_name, strategy_configs in strategies.items():
        strategy_dir = os.path.join(results_root, strategy_name.replace(" ", "_"))
        rows, stats = run_strategy(
            strategy_name=strategy_name,
            configs=strategy_configs,
            src_file=src_file,
            top_func=top_func,
            results_dir=strategy_dir,
        )
        all_stats.append(stats)
        save_csv(rows, os.path.join(results_root, f"{strategy_name.replace(' ', '_')}_results.csv"))

    pa = PADSE(
        src_file=src_file,
        top_func=top_func,
        benchmark_name=benchmark,
        results_dir=os.path.join(results_root, "PA_DSE"),
        budget=budget,
        autophagy_threshold=2,
        ablation_mode=ablation_mode,
    )
    pa_result = pa.explore(configs)
    all_stats.append(pa_result.stats)
    save_csv(pa_result.all_results, os.path.join(results_root, "PA_DSE_results.csv"))

    stats_df = pd.DataFrame(all_stats)
    stats_path = os.path.join(results_root, "pa_dse_comparison_stats.csv")
    stats_df.to_csv(stats_path, index=False)

    print("\n=== Summary ===")
    print(stats_df.to_string(index=False))
    print(f"\nSaved {stats_path}")

    if pa_result.learned_rules:
        rules_path = os.path.join(results_root, "pa_dse_learned_rules.txt")
        with open(rules_path, "w", encoding="utf-8") as f:
            for line in pa_result.learned_rules:
                f.write(line + "\n")
        print(f"Saved {rules_path}")

    if pa_result.static_log:
        log_df = pd.DataFrame(pa_result.static_log)
        log_path = os.path.join(results_root, "pa_dse_static_pruning_log.csv")
        log_df.to_csv(log_path, index=False)
        print(f"Saved {log_path}")


def main():
    parser = argparse.ArgumentParser(description="Run PA-DSE and compare against baselines.")
    parser.add_argument("--benchmark", type=str, default="matmul", choices=["matmul", "fir", "vadd", "histogram"])
    parser.add_argument("--src", type=str, default=None)
    parser.add_argument("--top", type=str, default=None)
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--results-root", type=str, default="results/pa_dse")
    parser.add_argument("--enable-pipeline", action="store_true")
    parser.add_argument(
        "--ablation",
        type=str,
        default="full",
        choices=["no_filter", "static_only", "full"],
        help="Ablation mode: no_filter / static_only / full",
    )
    args = parser.parse_args()

    if args.src is None or args.top is None:
        src_file, top_func = BENCHMARK_DEFAULTS[args.benchmark]
        if args.src is not None:
            src_file = args.src
        if args.top is not None:
            top_func = args.top
    else:
        src_file, top_func = args.src, args.top

    mode_dir = "with_pipeline" if args.enable_pipeline else "no_pipeline"
    if args.ablation != "full":
        mode_dir = mode_dir + "_" + args.ablation
    results_root = os.path.join(args.results_root, args.benchmark, mode_dir)

    run_all(
        benchmark=args.benchmark,
        src_file=src_file,
        top_func=top_func,
        results_root=results_root,
        budget=args.budget,
        enable_pipeline=args.enable_pipeline,
        ablation_mode=args.ablation,
    )


if __name__ == "__main__":
    main()
